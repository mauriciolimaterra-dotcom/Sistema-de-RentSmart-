# RentSmart — Sistema de Orçamento de Locação

**Aluno:** Mauricio de Lima Terra  
**RA:** 245678  
**Turma:** Manhã  
**Curso:** Análise e Desenvolvimento de Sistemas (ADS)

## Como executar
1. Tenha o Python 3 instalado.
2. Abra o terminal na pasta do projeto.
3. Execute `python rentsmart.py`.
4. Responda às perguntas. O programa mostra o orçamento e gera o arquivo `projecao_12_meses.csv`.

O projeto usa somente bibliotecas que já acompanham o Python.
